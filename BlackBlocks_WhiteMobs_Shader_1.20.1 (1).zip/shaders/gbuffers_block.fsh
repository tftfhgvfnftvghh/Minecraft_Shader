#version 120
uniform sampler2D texture;
varying vec2 texcoord;
varying vec4 vertexColor;
void main() {
    vec4 tex = texture2D(texture, texcoord) * vertexColor;
    if (tex.a < 0.1) discard;
    gl_FragColor = vec4(0.0, 0.0, 0.0, tex.a);
}
