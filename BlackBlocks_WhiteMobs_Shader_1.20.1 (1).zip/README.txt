BLACK BLOCKS, WHITE MOBS — Shaderpack ZIP
Target: Minecraft Java 1.20.1 with compatible Iris or OptiFine.

FORMAT
This archive has a `shaders/` folder at its root, the format expected for
an OptiFine/Iris shaderpack upload.

INSTALL
Keep the ZIP zipped. Put it in .minecraft/shaderpacks, then select it in
Options > Video Settings > Shader Packs.

EFFECT
- Common terrain/block passes render black.
- Common entity passes render white.
- Transparent pixels are preserved.

LIMITATIONS
This is a minimal shaderpack and has not been runtime-tested. Special render
layers, fluids, particles, GUI, modded renderers, and other shader pipeline
paths may retain normal colors. Dropped item entities can render white because
some Minecraft rendering paths share entity passes between mobs and items.
